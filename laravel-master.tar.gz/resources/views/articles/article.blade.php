@extends ('app')

@section('content')
    <h1> Write a new aticle </h1>

    <hr/>

    <form></form>
@endsection