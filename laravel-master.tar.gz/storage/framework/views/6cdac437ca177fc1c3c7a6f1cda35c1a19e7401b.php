<?php $__env->startSection('content'); ?>
    <h1>Articles</h1>
    <hr/>
        <article>
            <?php echo e($article->body); ?>

        </article>

    <?php if (! ($article->tags->isEmpty())): ?>
        <h5>Tags: </h5>
        <ul>
            <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($tag->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>